function Score() {
	
}